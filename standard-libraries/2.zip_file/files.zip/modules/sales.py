
def calc_tax():
    print("Calculating tax...")


def calc_shipping():
    print("Calculating shipping...")
