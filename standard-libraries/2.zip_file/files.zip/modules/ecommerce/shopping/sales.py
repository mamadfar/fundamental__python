
# from ..customer.contact import contact_customer
# from ecommerce.customer.contact import contact_customer

# print("Sales module loaded.", __name__)

# contact_customer()


def calc_tax():
    print("Calculating tax...")


def calc_shipping():
    print("Calculating shipping...")


if __name__ == "__main__":
    print("Sales started")
    calc_tax()
