
# This file makes the modules directory a Python package
print("ecommerce package initialized")
